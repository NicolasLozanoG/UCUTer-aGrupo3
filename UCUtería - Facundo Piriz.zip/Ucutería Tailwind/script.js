const PRODUCTS = [
    { id: "c1", name: "Espresso", price: 120, category: "Café", img: "☕️", desc: "Corto e intenso." },
    { id: "c2", name: "Latte", price: 180, category: "Café", img: "🥛☕️", desc: "Con leche espumada." },
    { id: "t1", name: "Té Verde", price: 140, category: "Té", img: "🍵", desc: "Suave y herbal." },
    { id: "t2", name: "Té Chai", price: 160, category: "Té", img: "🫖", desc: "Especias aromáticas." },
    { id: "p1", name: "Medialuna", price: 90, category: "Pastelería", img: "🥐", desc: "Mantecosas y doradas." },
    { id: "p2", name: "Torta Choc", price: 220, category: "Pastelería", img: "🍰", desc: "Fudge intenso." },
    { id: "s1", name: "Sándwich Jamón", price: 260, category: "Sándwiches", img: "🥪", desc: "Clásico de la casa." },
    { id: "s2", name: "Veggie Grill", price: 280, category: "Sándwiches", img: "🥗", desc: "Verduras asadas." }
];

const cuponInput = document.getElementById("cuponInput");
const cuponMsg = document.getElementById("cuponMsg");
const listaProductosEl = document.getElementById("miLista");
const contadorEl = document.getElementById("contadorCarrito");
const carritoPanel = document.getElementById("carritoPanel");
const modal = document.getElementById("checkoutModal");

let carrito = JSON.parse(localStorage.getItem("carrito")) || [];
let descuento = 0;
let filtroCategoria = "Todos";

function renderLista(filtro = "") {
    listaProductosEl.innerHTML = "";

    let productos = PRODUCTS.filter(p => p.name.toLowerCase().includes(filtro.toLowerCase()));
    if (filtroCategoria !== "Todos") productos = productos.filter(p => p.category === filtroCategoria);

    const ordenar = document.getElementById("ordenar").value;
    if (ordenar === "precio-asc") productos.sort((a, b) => a.price - b.price);
    if (ordenar === "precio-desc") productos.sort((a, b) => b.price - a.price);
    if (ordenar === "alf-asc") productos.sort((a, b) => a.name.localeCompare(b.name));
    if (ordenar === "alf-desc") productos.sort((a, b) => b.name.localeCompare(a.name));

    productos.forEach(p => {
        const li = document.createElement("li");
        li.className = "p-4 bg-white dark:bg-gray-800 rounded-xl shadow hover:shadow-lg transition flex flex-col items-center text-center";
        li.innerHTML = `
      <h3 class="text-lg font-bold">${p.img} ${p.name}</h3>
      <p class="text-gray-600 dark:text-gray-300 mt-1">${p.desc}</p>
      <p class="text-blue-700 dark:text-blue-400 font-semibold mt-2">$${p.price}</p>
      <button onclick='agregarAlCarrito("${p.id}")' class="mt-3 bg-blue-700 text-white px-4 py-2 rounded-full hover:bg-blue-900 transition">Añadir al carrito</button>
    `;
        listaProductosEl.appendChild(li);
    });
}

function agregarAlCarrito(id) {
    const prod = PRODUCTS.find(p => p.id === id);
    const item = carrito.find(i => i.id === id);
    if (item) item.cant++;
    else carrito.push({ ...prod, cant: 1 });
    guardarCarrito();
}

function eliminarDelCarrito(id) {
    carrito = carrito.filter(i => i.id !== id);
    guardarCarrito();
}

function cambiarCantidad(id, delta) {
    const item = carrito.find(i => i.id === id);
    if (!item) return;
    item.cant += delta;
    if (item.cant <= 0) carrito = carrito.filter(i => i.id !== id);
    guardarCarrito();
}

function guardarCarrito() {
    localStorage.setItem("carrito", JSON.stringify(carrito));
    renderCarrito();
}

function renderCarrito() {
    const lista = document.getElementById("listaCarrito");
    if (!lista) return;

    lista.innerHTML = carrito.map(i => `
    <li class="flex items-center justify-between bg-gray-100 dark:bg-gray-700 p-2 rounded-lg shadow-sm">
      <div class="text-sm">${i.name} x${i.cant} = $${i.price * i.cant}</div>
      <div class="flex gap-1">
        <button onclick="cambiarCantidad('${i.id}',1)" class="px-2 bg-green-600 text-white rounded hover:bg-green-800">+</button>
        <button onclick="cambiarCantidad('${i.id}',-1)" class="px-2 bg-yellow-600 text-white rounded hover:bg-yellow-800">-</button>
        <button onclick="eliminarDelCarrito('${i.id}')" class="px-2 bg-red-600 text-white rounded hover:bg-red-800">❌</button>
      </div>
    </li>
  `).join("") || '<li class="text-sm text-gray-500">El carrito está vacío.</li>';

    let subtotal = carrito.reduce((a, i) => a + i.price * i.cant, 0);
    subtotal = subtotal - subtotal * descuento;
    const iva = subtotal * 0.22;
    const envio = subtotal >= 600 ? 0 : 120;
    const total = subtotal + iva + envio;

    document.getElementById("subtotal").textContent = subtotal.toFixed(0);
    document.getElementById("iva").textContent = iva.toFixed(0);
    document.getElementById("envio").textContent = envio;
    document.getElementById("total").textContent = total.toFixed(0);
    contadorEl.textContent = carrito.reduce((a, i) => a + i.cant, 0);
}


const carritoIcon = document.getElementById("carritoIcon");
if (carritoIcon) {
    carritoIcon.addEventListener("click", () => {
        carritoPanel.classList.toggle("open");
    });
}
const cerrarCarritoBtn = document.getElementById("cerrarCarrito");
if (cerrarCarritoBtn) {
    cerrarCarritoBtn.addEventListener("click", () => carritoPanel.classList.remove("open"));
}

const vaciarBtn = document.getElementById("vaciarCarrito");
if (vaciarBtn) vaciarBtn.addEventListener("click", () => { carrito = []; guardarCarrito(); });

const busqueda = document.getElementById("busqueda");
if (busqueda) busqueda.addEventListener("input", e => renderLista(e.target.value));
document.querySelectorAll("#filtros button").forEach(btn => {
    btn.addEventListener("click", () => {
        filtroCategoria = btn.dataset.cat;
        renderLista(document.getElementById("busqueda").value);
    });
});
const ordenarSel = document.getElementById("ordenar");
if (ordenarSel) ordenarSel.addEventListener("change", () => renderLista(document.getElementById("busqueda").value));

const checkoutBtn = document.getElementById("checkoutBtn");
const cerrarModalBtn = document.getElementById("cerrarModal");
if (checkoutBtn) {
    checkoutBtn.addEventListener("click", () => {
        if (carrito.length === 0) {
            alert("No puedes finalizar la compra con el carrito vacío.");
            return;
        }
        modal.classList.remove("hidden");
        modal.classList.add("flex");
    });
}
if (cerrarModalBtn) {
    cerrarModalBtn.addEventListener("click", () => {
        modal.classList.add("hidden");
        modal.classList.remove("flex");
    });
}
modal.addEventListener("click", (e) => {
    if (e.target === modal) {
        modal.classList.add("hidden");
        modal.classList.remove("flex");
    }
});
document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") {
        if (!modal.classList.contains("hidden")) {
            modal.classList.add("hidden");
            modal.classList.remove("flex");
        }
    }
});

const checkoutForm = document.getElementById("checkoutForm");
if (checkoutForm) {
    checkoutForm.addEventListener("submit", e => {
        e.preventDefault();
        if (carrito.length === 0) {
            alert("No puedes finalizar la compra con el carrito vacío.");
            return;
        }
        alert("¡Pedido confirmado!");
        carrito = [];
        guardarCarrito();
        modal.classList.add("hidden");
        modal.classList.remove("flex");
    });
}

document.addEventListener("DOMContentLoaded", () => {
    const toggleDark = document.getElementById("toggleDark");

    if (
        localStorage.theme === "dark" ||
        (!("theme" in localStorage) && window.matchMedia("(prefers-color-scheme: dark)").matches)
    ) {
        document.documentElement.classList.add("dark");
        toggleDark.textContent = "🌙";
    } else {
        document.documentElement.classList.remove("dark");
        toggleDark.textContent = "☀️";
    }

    toggleDark.addEventListener("click", () => {
        const html = document.documentElement;
        html.classList.toggle("dark");
        if (html.classList.contains("dark")) {
            localStorage.setItem("theme", "dark");
            toggleDark.textContent = "🌙";
        } else {
            localStorage.setItem("theme", "light");
            toggleDark.textContent = "☀️";
        }
    });
});

const aplicarCuponBtn = document.getElementById("aplicarCupon");
if (aplicarCuponBtn) {
    aplicarCuponBtn.addEventListener("click", () => {
        const code = (cuponInput?.value || "").trim().toUpperCase();
        if (code === "UCUDESC10") {
            descuento = 0.1;
            cuponMsg.textContent = "Cupón válido: 10% de descuento aplicado.";
            cuponMsg.style.color = "green";
        } else if (code === "") {
            descuento = 0;
            cuponMsg.textContent = "Ingresa un código de cupón.";
            cuponMsg.style.color = "orange";
        } else {
            descuento = 0;
            cuponMsg.textContent = "Cupón inválido.";
            cuponMsg.style.color = "red";
        }
        renderCarrito();
    });
}

renderLista();
renderCarrito();
