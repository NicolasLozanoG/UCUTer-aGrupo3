const PRODUCTS = [
    { id: "c1", name: "Espresso", price: 120, category: "Café", img: "☕️", desc: "Corto e intenso." },
    { id: "c2", name: "Latte", price: 180, category: "Café", img: "🥛☕️", desc: "Con leche espumada." },
    { id: "t1", name: "Té Verde", price: 140, category: "Té", img: "🍵", desc: "Suave y herbal." },
    { id: "t2", name: "Té Chai", price: 160, category: "Té", img: "🫖", desc: "Especias aromáticas." },
    { id: "p1", name: "Medialuna", price: 90, category: "Pastelería", img: "🥐", desc: "Mantecosas y doradas." },
    { id: "p2", name: "Torta Choc", price: 220, category: "Pastelería", img: "🍰", desc: "Fudge intenso." },
    { id: "s1", name: "Sándwich Jamón", price: 260, category: "Sándwiches", img: "🥪", desc: "Clásico de la casa." },
    { id: "s2", name: "Veggie Grill", price: 280, category: "Sándwiches", img: "🥗", desc: "Verduras asadas." }
];

const cuponInput = document.getElementById("cuponInput");
const cuponMsg = document.getElementById("cuponMsg");
let carrito = JSON.parse(localStorage.getItem("carrito")) || [];
let descuento = 0;
let filtroCategoria = "Todos";

function renderLista(filtro=""){
    const lista = document.getElementById("miLista");
    lista.innerHTML = "";

    let productos = PRODUCTS
        .filter(p=>p.name.toLowerCase().includes(filtro.toLowerCase()));

    if(filtroCategoria!=="Todos"){
        productos = productos.filter(p=>p.category===filtroCategoria);
    }

    const ordenar = document.getElementById("ordenar").value;
    if(ordenar==="precio-asc") productos.sort((a,b)=>a.price-b.price);
    if(ordenar==="precio-desc") productos.sort((a,b)=>b.price-a.price);
    if(ordenar==="alf-asc") productos.sort((a,b)=>a.name.localeCompare(b.name));
    if(ordenar==="alf-desc") productos.sort((a,b)=>b.name.localeCompare(a.name));

    productos.forEach(p=>{
        const li = document.createElement("li");
        li.innerHTML = `
      <h3>${p.img} ${p.name}</h3>
      <p>${p.desc}</p>
      <p><strong>$${p.price}</strong></p>
      <button onclick='agregarAlCarrito("${p.id}")'>Añadir al carrito</button>
    `;
        lista.appendChild(li);
    });
}


function agregarAlCarrito(id){
    const prod = PRODUCTS.find(p=>p.id===id);
    const item = carrito.find(i=>i.id===id);
    if(item) item.cant++;
    else carrito.push({...prod,cant:1});
    guardarCarrito();
}

function eliminarDelCarrito(id){
    carrito = carrito.filter(i=>i.id!==id);
    guardarCarrito();
}

function cambiarCantidad(id, delta){
    const item = carrito.find(i=>i.id===id);
    if(!item) return;
    item.cant += delta;
    if(item.cant<=0) carrito = carrito.filter(i => i.id!==id);
    guardarCarrito();
}

function guardarCarrito(){
    localStorage.setItem("carrito", JSON.stringify(carrito));
    renderCarrito();
}

function renderCarrito(){
    const lista = document.getElementById("listaCarrito");
    lista.innerHTML = carrito.map(i=>
        `<li>${i.name} x${i.cant} = $${i.price*i.cant}
      <button onclick="cambiarCantidad('${i.id}',1)">+</button>
      <button onclick="cambiarCantidad('${i.id}',-1)">-</button>
      <button onclick="eliminarDelCarrito('${i.id}')">❌</button>
    </li>`).join("");

    let subtotal = carrito.reduce((a,i)=>a+i.price*i.cant,0);
    subtotal = subtotal - subtotal*descuento;
    const iva = subtotal*0.22;
    const envio = subtotal>=600?0:120;
    const total = subtotal+iva+envio;

    document.getElementById("subtotal").textContent = subtotal.toFixed(0);
    document.getElementById("iva").textContent = iva.toFixed(0);
    document.getElementById("envio").textContent = envio;
    document.getElementById("total").textContent = total.toFixed(0);
    document.getElementById("contadorCarrito").textContent = carrito.reduce((a,i)=>a+i.cant,0);
}

document.getElementById("carritoIcon").addEventListener("click", ()=>{
    document.getElementById("carritoPanel").classList.toggle("open");
});

document.getElementById("cerrarCarrito").addEventListener("click", ()=>{
    document.getElementById("carritoPanel").classList.remove("open");
});

document.getElementById("vaciarCarrito").addEventListener("click", ()=>{
    carrito=[];
    guardarCarrito();
});

document.getElementById("busqueda").addEventListener("input", e=>{
    renderLista(e.target.value);
});

document.querySelectorAll("#filtros button").forEach(btn=>{
    btn.addEventListener("click", ()=>{
        filtroCategoria = btn.dataset.cat;
        renderLista(document.getElementById("busqueda").value);
    });
});

document.getElementById("ordenar").addEventListener("change", ()=>{
    renderLista(document.getElementById("busqueda").value);
});

document.getElementById("cuponInput").addEventListener("change", e=>{
    cupon = e.target.value.trim();
    localStorage.setItem("cupon", cupon);
    renderCarrito();
});

const modal = document.getElementById("checkoutModal");
document.getElementById("checkoutBtn").addEventListener("click", ()=>{
    if (carrito.length === 0) {
        alert("No puedes finalizar la compra con el carrito vacío.");
        return;
    }
    modal.style.display = "flex";
});
document.getElementById("cerrarModal").addEventListener("click", ()=>{
    modal.style.display = "none";
});
document.getElementById("checkoutForm").addEventListener("submit", e=>{
    e.preventDefault();
    if (carrito.length === 0) {
        alert("No puedes finalizar la compra con el carrito vacío.");
        return;
    }
    alert("¡Pedido confirmado!");
    carrito=[];
    guardarCarrito();
    modal.style.display = "none";
});

const toggle = document.getElementById("toggleDark");

if(localStorage.getItem("modo") === "dark"){
    document.body.classList.add("dark");
}

toggle.addEventListener("click", ()=>{
    document.body.classList.toggle("dark");

    if(document.body.classList.contains("dark")){
        localStorage.setItem("modo", "dark");
    } else {
        localStorage.setItem("modo", "light");
    }
});


if(localStorage.getItem("modo")==="dark"){
    document.body.classList.add("dark");
}


const aplicarCuponBtn = document.getElementById("aplicarCupon");

aplicarCuponBtn.addEventListener("click", () => {
    const code = cuponInput.value.trim().toUpperCase();

    if (code === "UCUDESC10") {
        descuento = 0.1;
        cuponMsg.textContent = "Cupón válido: 10% de descuento aplicado.";
        cuponMsg.style.color = "green";
    } else if (code === "") {
        descuento = 0;
        cuponMsg.textContent = "Ingresa un código de cupón.";
        cuponMsg.style.color = "orange";
    } else {
        descuento = 0;
        cuponMsg.textContent = "Cupón inválido.";
        cuponMsg.style.color = "red";
    }

    renderCarrito();
});

renderLista();
renderCarrito();
